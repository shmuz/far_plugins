/**************************************************************************
 *  SQLiteDB plug-in for FAR 3.0                                          *
 *  Copyright (C) 2010-2014 by Artem Senichev <artemsen@gmail.com>        *
 *  https://sourceforge.net/projects/farplugs/                            *
 *                                                                        *
 *  This program is free software: you can redistribute it and/or modify  *
 *  it under the terms of the GNU General Public License as published by  *
 *  the Free Software Foundation, either version 3 of the License, or     *
 *  (at your option) any later version.                                   *
 *                                                                        *
 *  This program is distributed in the hope that it will be useful,       *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *  GNU General Public License for more details.                          *
 *                                                                        *
 *  You should have received a copy of the GNU General Public License     *
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. *
 **************************************************************************/

#include "settings.h"
#include "string_rc.h"

bool settings::add_to_panel_menu = false;
wstring settings::prefix = L"SQLiteDB";

const wchar_t* param_add_pm = L"add_pm";
const wchar_t* param_prefix = L"prefix";


void settings::load()
{
	FarSettingsCreate fsc;
	ZeroMemory(&fsc, sizeof(fsc));
	fsc.StructSize = sizeof(fsc);
	fsc.Guid = _FPG;
	fsc.Handle = INVALID_HANDLE_VALUE;
	if (!_PSI.SettingsControl(INVALID_HANDLE_VALUE, SCTL_CREATE, 0, &fsc))
		return;

	FarSettingsItem fsi;
	ZeroMemory(&fsi, sizeof(fsi));
	fsi.StructSize = sizeof(fsi);

	fsi.Name = param_add_pm;
	fsi.Type = FST_QWORD;
	if (_PSI.SettingsControl(fsc.Handle, SCTL_GET, 0, &fsi))
		add_to_panel_menu = fsi.Number != 0;

	fsi.Name = param_prefix;
	fsi.Type = FST_STRING;
	if (_PSI.SettingsControl(fsc.Handle, SCTL_GET, 0, &fsi))
		prefix = fsi.String;

	_PSI.SettingsControl(fsc.Handle, SCTL_FREE, 0, nullptr);
}


void settings::configure()
{
	FarDialogItem dlg_items[7];
	ZeroMemory(dlg_items, sizeof(dlg_items));

	dlg_items[0].Type = DI_DOUBLEBOX;
	dlg_items[0].X1 = 3;
	dlg_items[0].X2 = 46;
	dlg_items[0].Y1 = 1;
	dlg_items[0].Y2 = 6;
	dlg_items[0].Data = _PSI.GetMsg(&_FPG, ps_title);

	dlg_items[1].Type = DI_CHECKBOX;
	dlg_items[1].X1 = 5;
	dlg_items[1].X2 = 46;
	dlg_items[1].Y1 = 2;
	dlg_items[1].Data = _PSI.GetMsg(&_FPG, ps_cfg_add_pm);
	dlg_items[1].Selected = add_to_panel_menu ? 1 : 0;

	dlg_items[2].Type = DI_TEXT;
	dlg_items[2].X1 = 5;
	dlg_items[2].X2 = 13;
	dlg_items[2].Y1 = 3;
	dlg_items[2].Data = _PSI.GetMsg(&_FPG, ps_cfg_prefix);

	dlg_items[3].Type = DI_EDIT;
	dlg_items[3].X1 = 14;
	dlg_items[3].X2 = 44;
	dlg_items[3].Y1 = 3;
	dlg_items[3].Data = prefix.c_str();

	dlg_items[4].Type = DI_TEXT;
	dlg_items[4].Y1 = 4;
	dlg_items[4].Flags = DIF_SEPARATOR;

	dlg_items[5].Type = DI_BUTTON;
	dlg_items[5].Data = _PSI.GetMsg(&_FPG, ps_save);
	dlg_items[5].Y1 = 5;
	dlg_items[5].Flags = DIF_CENTERGROUP | DIF_DEFAULTBUTTON | DIF_FOCUS;

	dlg_items[6].Type = DI_BUTTON;
	dlg_items[6].Data = _PSI.GetMsg(&_FPG, ps_cancel);
	dlg_items[6].Y1 = 5;
	dlg_items[6].Flags = DIF_CENTERGROUP;

	const HANDLE dlg = _PSI.DialogInit(&_FPG, &_FPG, -1, -1, 50, 8, nullptr, dlg_items, sizeof(dlg_items) / sizeof(dlg_items[0]), 0, FDLG_NONE, nullptr, nullptr);
	const intptr_t rc = _PSI.DialogRun(dlg);
	if (rc >= 0 && rc != 6 /* cancel */) {
		add_to_panel_menu = _PSI.SendDlgMessage(dlg, DM_GETCHECK, 1, nullptr) != 0;
		prefix = reinterpret_cast<const wchar_t*>(_PSI.SendDlgMessage(dlg, DM_GETCONSTTEXTPTR, 3, nullptr));
		save();
	}
	_PSI.DialogFree(dlg);
}


void settings::save()
{
	FarSettingsCreate fsc;
	ZeroMemory(&fsc, sizeof(fsc));
	fsc.StructSize = sizeof(fsc);
	fsc.Guid = _FPG;
	fsc.Handle = INVALID_HANDLE_VALUE;
	if (!_PSI.SettingsControl(INVALID_HANDLE_VALUE, SCTL_CREATE, 0, &fsc))
		return;

	FarSettingsItem fsi;
	ZeroMemory(&fsi, sizeof(fsi));
	fsi.StructSize = sizeof(fsi);

	fsi.Name = param_add_pm;
	fsi.Type = FST_QWORD;
	fsi.Number = add_to_panel_menu ? 1 : 0;
	_PSI.SettingsControl(fsc.Handle, SCTL_SET, 0, &fsi);

	fsi.Name = param_prefix;
	fsi.Type = FST_STRING;
	fsi.String = prefix.c_str();
	_PSI.SettingsControl(fsc.Handle, SCTL_SET, 0, &fsi);

	_PSI.SettingsControl(fsc.Handle, SCTL_FREE, 0, nullptr);
}
