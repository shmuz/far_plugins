/**************************************************************************
 *  SQLiteDB plug-in for FAR 3.0                                          *
 *  Copyright (C) 2010-2014 by Artem Senichev <artemsen@gmail.com>        *
 *  https://sourceforge.net/projects/farplugs/                            *
 *                                                                        *
 *  This program is free software: you can redistribute it and/or modify  *
 *  it under the terms of the GNU General Public License as published by  *
 *  the Free Software Foundation, either version 3 of the License, or     *
 *  (at your option) any later version.                                   *
 *                                                                        *
 *  This program is distributed in the hope that it will be useful,       *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *  GNU General Public License for more details.                          *
 *                                                                        *
 *  You should have received a copy of the GNU General Public License     *
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. *
 **************************************************************************/

#include "panel.h"
#include "string_rc.h"
#include "settings.h"
#include "progress.h"
#include "exporter.h"
#include "editor.h"


panel* panel::open(const wchar_t* file_name, const bool silent)
{
	assert(file_name != nullptr && file_name[0] != 0);

	panel* instance = new panel();
	instance->_file_name = file_name;

	if (!instance->_db.open(file_name) || !instance->open_database()) {
		delete instance;
		instance = nullptr;
		if (!silent) {
			const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_open), file_name };
			_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
		}
	}

	return instance;
}


bool panel::open_database()
{
	_panel_mode = pm_db;
	_curr_object.clear();
	prepare_panel_info();
	return true;
}


bool panel::open_object(const wchar_t* object_name)
{
	assert(object_name && object_name[0]);

	switch (_db.get_object_type(object_name)) {
		case sqlite::ot_master:
		case sqlite::ot_table:
			_panel_mode = pm_table;
			break;
		case sqlite::ot_view:
			_panel_mode = pm_view;
			break;
		default:
			return false;
	}

	_curr_object = object_name;

	_column_descr.clear();
	if (!_db.read_column_description(object_name, _column_descr)) {
		const wstring err_descr = _db.last_error();
		const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_read), err_descr.c_str() };
		_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
		return false;
	}

	prepare_panel_info();

	return true;
}


bool panel::open_query(const wchar_t* query)
{
	assert(query && query[0]);

	if (!query || query[0] == 0)
		return false;

	_last_sql_query = query;

	//Check query for select
	const wchar_t* select_word = query;
	while (select_word[0] && !iswalpha(select_word[0]))
		++select_word;
	if (_wcsnicmp(select_word, L"select", 6 /* sizeof(select) */) != 0) {
		//Update query - just execute without read result
		progress prg_wnd(ps_execsql);
		if (!_db.execute_query(query)) {
			prg_wnd.hide();
			const wstring err_descr = _db.last_error();
			const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_sql), query, err_descr.c_str() };
			_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
			return false;
		}
	}
	else {
		_panel_mode = pm_query;
		_curr_object = query;

		//Get column description
		sqlite_statement stmt(_db.db());
		if (stmt.prepare(query) != SQLITE_OK || (stmt.step_execute() != SQLITE_ROW && stmt.step_execute() != SQLITE_DONE)) {
			const wstring err_descr = _db.last_error();
			const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_sql), query, err_descr.c_str() };
			_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
			return false;
		}

		_column_descr.clear();
		const int col_count = stmt.column_count();
		for (int i = 0; i < col_count; ++i) {
			sqlite::sq_column col;
			col.name = stmt.column_name(i);
			col.type = sqlite::ct_text;
			_column_descr.push_back(col);
		}

		prepare_panel_info();
	}

	_PSI.PanelControl(this, FCTL_UPDATEPANEL, 0, nullptr);
	PanelRedrawInfo pri;
	ZeroMemory(&pri, sizeof(pri));
	pri.StructSize = sizeof(pri);
	_PSI.PanelControl(this, FCTL_REDRAWPANEL, 0, &pri);

	return true;
}


void panel::get_panel_info(OpenPanelInfo* info)
{
	assert(info);

	info->StructSize = sizeof(info);

	info->Flags = OPIF_DISABLESORTGROUPS | OPIF_DISABLEFILTER;
	info->PanelTitle = _panel_info.title.c_str();
	info->CurDir = _curr_object.c_str();
	info->HostFile = _file_name.c_str();

	info->StartPanelMode = '0';
	info->PanelModesArray = &_panel_info.modes.front();
	info->PanelModesNumber = _panel_info.modes.size();

	static KeyBarTitles kb;
	kb.Labels = const_cast<KeyBarLabel*>(&_panel_info.key_bar.front());
	kb.CountLabels = _panel_info.key_bar.size();
	info->KeyBar = &kb;
}


bool panel::get_panel_list(PluginPanelItem** items, size_t& items_count)
{
	bool rc = false;
	switch (_panel_mode) {
		case pm_db:
			rc = get_panel_list_db(items, items_count);
			break;
		case pm_table:
		case pm_view:
			rc = get_panel_list_obj(items, items_count);
			break;
		case pm_query:
			rc = get_panel_list_query(items, items_count);
			break;
	}
	return rc;
}


bool panel::get_panel_list_db(PluginPanelItem** items, size_t& items_count)
{
	progress prg_wnd(ps_reading);

	sqlite::sq_objects db_objects;
	if (!_db.get_objects_list(db_objects)) {
		prg_wnd.hide();
		const wstring err_descr = _db.last_error();
		const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_read), _file_name.c_str(), err_descr.c_str() };
		_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
		return false;
	}
	items_count = db_objects.size() + 1;
	*items = new PluginPanelItem[items_count];
	ZeroMemory(*items, sizeof(PluginPanelItem) * items_count);

	//All dots (..)
	(*items)[0].FileName = alloc_copy(L"..");

	for (size_t i = 0; i < items_count - 1; ++i) {
		PluginPanelItem& item = (*items)[i + 1];
		item.FileSize = db_objects[i].row_count;
		if (db_objects[i].type == sqlite::ot_master || db_objects[i].type == sqlite::ot_table || db_objects[i].type == sqlite::ot_view)
			item.FileAttributes = FILE_ATTRIBUTE_DIRECTORY;
		item.FileName = alloc_copy(db_objects[i].name.c_str());
		item.AllocationSize = db_objects[i].type;	//This field used as type id

		wchar_t** custom_column_data = new wchar_t*[2];
		item.CustomColumnData = custom_column_data;
		item.CustomColumnNumber = 2;

		const wchar_t* obj_type = L"?";
		switch (db_objects[i].type) {
			case sqlite::ot_master:	obj_type = L"metadata"; break;
			case sqlite::ot_table:	obj_type = L"table"; break;
			case sqlite::ot_view:	obj_type = L"view"; break;
			case sqlite::ot_index:	obj_type = L"index"; break;
		}
		custom_column_data[0] = alloc_copy(obj_type);

		custom_column_data[1] = new wchar_t[32];
		swprintf_s(custom_column_data[1], 32, L"% 9d", static_cast<int>(db_objects[i].row_count));
	}

	return true;
}


bool panel::get_panel_list_obj(PluginPanelItem** items, size_t& items_count)
{
	unsigned __int64 row_count = 0;
	if (!_db.get_row_count(_curr_object.c_str(), row_count)) {
		const wstring err_descr = _db.last_error();
		const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_read), err_descr.c_str() };
		_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
		return false;
	}

	progress prg_wnd(ps_reading, row_count);

	items_count = static_cast<size_t>(row_count) + 1;
	*items = new PluginPanelItem[items_count];
	ZeroMemory(*items, sizeof(PluginPanelItem) * items_count);

	//All dots (..)
	PluginPanelItem& dot_item = (*items)[0];
	dot_item.FileName = alloc_copy(L"..");
	const size_t dot_col_num = _column_descr.size();
	wchar_t** dot_custom_column_data = new wchar_t*[dot_col_num];
	for (size_t j = 0; j < dot_col_num; ++j)
		dot_custom_column_data[j] = alloc_copy(L"..");
	dot_item.CustomColumnData = dot_custom_column_data;
	dot_item.CustomColumnNumber = dot_col_num;

	wstring query = L"select rowid,* from '";
	query += _curr_object;
	query += L'\'';
	sqlite_statement stmt(_db.db());
	if (stmt.prepare(query.c_str()) != SQLITE_OK) {
		prg_wnd.hide();
		const wstring err_descr = _db.last_error();
		const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_read), err_descr.c_str() };
		_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
		return false;
	}
	const size_t col_num = _column_descr.size();
	for (size_t i = 0; i < items_count - 1; ++i) {
		if (i % 100 == 0)
			prg_wnd.update(i);
		if (stmt.step_execute() != SQLITE_ROW) {
			prg_wnd.hide();
			const wstring err_descr = _db.last_error();
			const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_read), err_descr.c_str() };
			_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
			free_panel_list(*items, items_count);
			return false;
		}
		if (progress::aborted()) {
			items_count = i + 1;
			return true;	//Show incomplete data
		}

		PluginPanelItem& item = (*items)[i + 1];
		wchar_t** custom_column_data = new wchar_t*[col_num];
		wstring row_data;
		for (size_t j = 0; j < col_num; ++j) {
			exporter::get_text(stmt, static_cast<int>(j) + 1 /* rowid */, row_data);
			custom_column_data[j] = alloc_copy(row_data.c_str());
		}
		item.AllocationSize = stmt.get_int64(0);	//This field used as row id
		item.CustomColumnData = custom_column_data;
		item.CustomColumnNumber = col_num;
	}
	prg_wnd.update(row_count);

	return true;
}


bool panel::get_panel_list_query(PluginPanelItem** items, size_t& items_count)
{
	progress prg_wnd(ps_reading);

	//Read all data to buffer - we don't know rowset size
	vector<PluginPanelItem> buff;

	//All dots (..)
	PluginPanelItem dot_item;
	ZeroMemory(&dot_item, sizeof(dot_item));
	dot_item.FileName = alloc_copy(L"..");
	const size_t dot_col_num = _column_descr.size();
	wchar_t** dot_custom_column_data = new wchar_t*[dot_col_num];
	for (size_t j = 0; j < dot_col_num; ++j)
		dot_custom_column_data[j] = alloc_copy(L"..");
	dot_item.CustomColumnData = dot_custom_column_data;
	dot_item.CustomColumnNumber = dot_col_num;
	buff.push_back(dot_item);

	sqlite_statement stmt(_db.db());
	if (stmt.prepare(_curr_object.c_str()) != SQLITE_OK) {
		prg_wnd.hide();
		const wstring err_descr = _db.last_error();
		const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_read), err_descr.c_str() };
		_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
		return false;
	}

	int state = SQLITE_OK;
	while ((state = stmt.step_execute()) == SQLITE_ROW) {
		if (progress::aborted()) {
			state = SQLITE_DONE;
			break;	//Show incomplete data
		}

		PluginPanelItem item;
		ZeroMemory(&item, sizeof(item));
		const int col_count = stmt.column_count();
		wchar_t** custom_column_data = new wchar_t*[col_count];
		wstring row_data;
		for (size_t j = 0; j < static_cast<size_t>(col_count); ++j) {
			exporter::get_text(stmt, static_cast<int>(j), row_data);
			custom_column_data[j] = alloc_copy(row_data.c_str());
		}
		item.CustomColumnData = custom_column_data;
		item.CustomColumnNumber = col_count;
		buff.push_back(item);
	}

	if (state != SQLITE_DONE) {
		prg_wnd.hide();
		const wstring err_descr = _db.last_error();
		const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_read), err_descr.c_str() };
		_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
		return false;
	}

	items_count = buff.size();
	*items = new PluginPanelItem[items_count];
	if (!buff.empty())
		memcpy(*items, &buff.front(), sizeof(PluginPanelItem) * buff.size());

	return true;
}


void panel::free_panel_list(PluginPanelItem* items, const size_t items_count)
{
	assert(items_count == 0 || items);

	for (size_t i = 0; i < items_count; ++i) {
		PluginPanelItem& item = items[i];
		delete[] item.FileName;
		for (size_t j = 0; j < item.CustomColumnNumber; ++j)
			delete[] item.CustomColumnData[j];
		delete[] item.CustomColumnData;
	}

	delete[] items;
}


bool panel::delete_items(PluginPanelItem* items, const size_t items_count)
{
	if (_panel_mode != pm_table && _panel_mode != pm_db)
		return false;
	editor ed(&_db, _curr_object.c_str());
	return ed.remove(items, items_count);
}


bool panel::handle_keyboard(const KEY_EVENT_RECORD& key_event)
{
	bool rc = false;

	//Ignored keys
	if ((key_event.dwControlKeyState == LEFT_CTRL_PRESSED || key_event.dwControlKeyState == RIGHT_CTRL_PRESSED) && key_event.wVirtualKeyCode == 'A')
		rc = true;
	else if (key_event.wVirtualKeyCode == VK_F7)
		rc = true;
	//F3 (view table/view data)
	else if (_panel_mode == pm_db && key_event.wVirtualKeyCode == VK_F3) {
		view_db_object();
		rc = true;
	}
	//F4 (view create statement)
	else if (_panel_mode == pm_db && key_event.dwControlKeyState == 0 && key_event.wVirtualKeyCode == VK_F4) {
		view_db_create_sql();
		rc = true;
	}
	//Shift-F4 (view pragma statement)
	else if (_panel_mode == pm_db && key_event.dwControlKeyState == SHIFT_PRESSED && key_event.wVirtualKeyCode == VK_F4) {
		view_pragma_statements();
		rc = true;
	}
	//F4 (edit row)
	else if (_panel_mode == pm_table && key_event.dwControlKeyState == 0 && (key_event.wVirtualKeyCode == VK_F4 || key_event.wVirtualKeyCode == VK_RETURN)) {
		bool can_be_handled = true;
		if (key_event.wVirtualKeyCode == VK_RETURN) {
			//Skip for '..'
			const intptr_t ppi_len = _PSI.PanelControl(PANEL_ACTIVE, FCTL_GETCURRENTPANELITEM, 0, nullptr);
			if (ppi_len != 0) {
				vector<unsigned char> buffer(ppi_len);
				PluginPanelItem* ppi = reinterpret_cast<PluginPanelItem*>(&buffer.front());
				FarGetPluginPanelItem fgppi;
				ZeroMemory(&fgppi, sizeof(fgppi));
				fgppi.StructSize = sizeof(fgppi);
				fgppi.Size = buffer.size();
				fgppi.Item = ppi;
				can_be_handled = _PSI.PanelControl(PANEL_ACTIVE, FCTL_GETCURRENTPANELITEM, 0, &fgppi) && wcscmp(ppi->FileName, L"..") != 0;
			}
		}
		if (can_be_handled) {
			editor re(&_db, _curr_object.c_str());
			re.update();
			rc = true;
		}
	}
	//Shift+F4 (insert row)
	else if (_panel_mode == pm_table && key_event.dwControlKeyState == SHIFT_PRESSED && key_event.wVirtualKeyCode == VK_F4) {
		editor re(&_db, _curr_object.c_str());
		re.insert();
		rc = true;
	}
	//F5 (export table/view data)
	else if (key_event.wVirtualKeyCode == VK_F5) {
		if (_panel_mode == pm_db) {
			exporter ex(&_db);
			ex.export_data();
		}
		rc = true;
	}
	//F6 (edit and execute SQL query)
	else if (key_event.wVirtualKeyCode == VK_F6) {
		edit_sql_query();
		rc = true;
	}
	return rc;
}


void panel::view_db_object()
{
	//Get selected object name
	const intptr_t ppi_len = _PSI.PanelControl(PANEL_ACTIVE, FCTL_GETCURRENTPANELITEM, 0, nullptr);
	if (ppi_len == 0)
		return;
	vector<unsigned char> buffer(ppi_len);
	PluginPanelItem* ppi = reinterpret_cast<PluginPanelItem*>(&buffer.front());
	FarGetPluginPanelItem fgppi;
	ZeroMemory(&fgppi, sizeof(fgppi));
	fgppi.StructSize = sizeof(fgppi);
	fgppi.Size = buffer.size();
	fgppi.Item = ppi;
	if (!_PSI.PanelControl(this, FCTL_GETCURRENTPANELITEM, 0, &fgppi))
		return;
	if (!ppi || wcscmp(ppi->FileName, L"..") == 0)
		return;

	wstring tmp_file_name;

	//For unknown types show create sql only
	if ((ppi->FileAttributes & FILE_ATTRIBUTE_DIRECTORY) == 0) {
		wstring cr_sql;
		if (!_db.get_creation_sql(ppi->FileName, cr_sql))
			return;
		tmp_file_name = exporter::get_temp_file_name(L"sql");

		HANDLE file = CreateFile(tmp_file_name.c_str(), GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
		if (file == INVALID_HANDLE_VALUE) {
			const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_writef), _file_name.c_str() };
			_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_ERRORTYPE | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
			return;
		}
		DWORD bytes_written;
		if (!WriteFile(file, cr_sql.c_str(), static_cast<DWORD>(cr_sql.length() * 2), &bytes_written, nullptr)) {
			const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_writef), _file_name.c_str() };
			_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_ERRORTYPE | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
			CloseHandle(file);
			return;
		}
		CloseHandle(file);
	}
	else {
		//Export data
		exporter ex(&_db);
		if (!ex.export_data(ppi->FileName, exporter::fmt_text, tmp_file_name))
			return;
	}
	wstring title = _PSI.GetMsg(&_FPG, ps_title_short);
	title += L": ";
	title += ppi->FileName;
	_PSI.Viewer(tmp_file_name.c_str(), title.c_str(), 0, 0, -1, -1, VF_ENABLE_F6 | VF_DISABLEHISTORY | VF_DELETEONLYFILEONCLOSE | VF_IMMEDIATERETURN | VF_NONMODAL, CP_UNICODE);
	ViewerSetMode vm;
	ZeroMemory(&vm, sizeof(vm));
	vm.StructSize = sizeof(vm);
	vm.Type = VSMT_WRAP;
	vm.iParam = 0;
	_PSI.ViewerControl(-1, VCTL_SETMODE, 0, &vm);
	vm.Type = VSMT_VIEWMODE;
	vm.Flags = VSMFL_REDRAW;
	vm.iParam = VMT_TEXT;
	_PSI.ViewerControl(-1, VCTL_SETMODE, 0, &vm);
}


void panel::view_db_create_sql()
{
	//Get selected object name
	const intptr_t ppi_len = _PSI.PanelControl(PANEL_ACTIVE, FCTL_GETCURRENTPANELITEM, 0, nullptr);
	if (ppi_len == 0)
		return;
	vector<unsigned char> buffer(ppi_len);
	PluginPanelItem* ppi = reinterpret_cast<PluginPanelItem*>(&buffer.front());
	FarGetPluginPanelItem fgppi;
	ZeroMemory(&fgppi, sizeof(fgppi));
	fgppi.StructSize = sizeof(fgppi);
	fgppi.Size = buffer.size();
	fgppi.Item = ppi;
	if (!_PSI.PanelControl(this, FCTL_GETCURRENTPANELITEM, 0, &fgppi))
		return;
	if (!ppi || wcscmp(ppi->FileName, L"..") == 0)
		return;

	wstring cr_sql;
	if (_db.get_creation_sql(ppi->FileName, cr_sql)) {
		wchar_t tmp_path[MAX_PATH] = { 0 };
		GetTempPath(MAX_PATH, tmp_path);
		GetTempFileName(tmp_path, L"sql", 0, tmp_path);
		wcscat_s(tmp_path, L".sql");

		HANDLE file = CreateFile(tmp_path, GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
		if (file == INVALID_HANDLE_VALUE) {
			const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_writef), _file_name.c_str() };
			_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_ERRORTYPE | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
			return;
		}
		DWORD bytes_written;
		if (!WriteFile(file, cr_sql.c_str(), static_cast<DWORD>(cr_sql.length() * 2), &bytes_written, nullptr)) {
			const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_writef), _file_name.c_str() };
			_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_ERRORTYPE | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
			CloseHandle(file);
			return;
		}
		CloseHandle(file);
		
		_PSI.Viewer(tmp_path, ppi->FileName, 0, 0, -1, -1, VF_ENABLE_F6 | VF_DISABLEHISTORY | VF_DELETEONLYFILEONCLOSE | VF_NONMODAL, CP_UNICODE);
	}
}


void panel::view_pragma_statements()
{
	const wchar_t* pst[] = {
		L"auto_vacuum", L"automatic_index", L"busy_timeout", L"cache_size",
		L"checkpoint_fullfsync", L"encoding", L"foreign_keys",
		L"freelist_count", L"fullfsync", L"ignore_check_constraints",
		L"integrity_check", L"journal_mode", L"journal_size_limit",
		L"legacy_file_format", L"locking_mode", L"max_page_count",
		L"page_count", L"page_size", L"quick_check", L"read_uncommitted",
		L"recursive_triggers", L"reverse_unordered_selects",
		L"schema_version", L"secure_delete", L"synchronous", L"temp_store",
		L"user_version", L"wal_autocheckpoint", L"wal_checkpoint"
	};
	vector<wstring> pragma_values;
	for (size_t i = 0; i < sizeof(pst) / sizeof(pst[0]); ++i) {
		wstring query = L"pragma ";
		query += pst[i];
		sqlite_statement stmt(_db.db());
		if (stmt.prepare(query.c_str()) == SQLITE_OK && stmt.step_execute() == SQLITE_ROW) {
			wstring pv = pst[i];
			pv += L": ";
			if (pv.length() < 28)
				pv.resize(28, L' ');
			pv += stmt.get_text(0);
			pragma_values.push_back(pv);
		}
	}
	if (pragma_values.empty())
		return;
	vector<FarListItem> far_items;
	far_items.resize(pragma_values.size());
	ZeroMemory(&far_items.front(), sizeof(FarListItem) * pragma_values.size());
	for (size_t i = 0; i < pragma_values.size(); ++i)
		far_items[i].Text = pragma_values[i].c_str();
	far_items[0].Flags |= LIF_SELECTED;
	FarList far_list;
	ZeroMemory(&far_list, sizeof(far_list));
	far_list.StructSize = sizeof(far_list);
	far_list.ItemsNumber = far_items.size();
	far_list.Items = &far_items.front();

	FarDialogItem dlg_items[4];
	ZeroMemory(dlg_items, sizeof(dlg_items));

	dlg_items[0].Type = DI_DOUBLEBOX;
	dlg_items[0].X1 = 3;
	dlg_items[0].X2 = 56;
	dlg_items[0].Y1 = 1;
	dlg_items[0].Y2 = 18;
	dlg_items[0].Data = _PSI.GetMsg(&_FPG, ps_title_pragma);

	dlg_items[1].Type = DI_LISTBOX;
	dlg_items[1].X1 = 4;
	dlg_items[1].X2 = 55;
	dlg_items[1].Y1 = 2;
	dlg_items[1].Y2 = 15;
	dlg_items[1].ListItems = &far_list;
	dlg_items[1].Flags = DIF_LISTNOBOX | DIF_LISTNOAMPERSAND | DIF_FOCUS;

	dlg_items[2].Type = DI_TEXT;
	dlg_items[2].Y1 = 16;
	dlg_items[2].Flags = DIF_SEPARATOR;

	dlg_items[3].Type = DI_BUTTON;
	dlg_items[3].Data = _PSI.GetMsg(&_FPG, ps_cancel);
	dlg_items[3].Y1 = 17;
	dlg_items[3].Flags = DIF_CENTERGROUP | DIF_DEFAULTBUTTON;

	const HANDLE dlg = _PSI.DialogInit(&_FPG, &_FPG, -1, -1, 60, 20, nullptr, dlg_items, sizeof(dlg_items) / sizeof(dlg_items[0]), 0, FDLG_NONE, nullptr, nullptr);
	_PSI.DialogRun(dlg);
}


void panel::edit_sql_query()
{
	const wstring tmp_file_name = exporter::get_temp_file_name(L"sql");

	//Save last used query
	if (!_last_sql_query.empty()) {
		HANDLE file = CreateFile(tmp_file_name.c_str(), GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
		if (file == INVALID_HANDLE_VALUE) {
			const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_writef), _file_name.c_str() };
			_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_ERRORTYPE | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
			return;
		}
		DWORD bytes_written;
		if (!WriteFile(file, _last_sql_query.c_str(), static_cast<DWORD>(_last_sql_query.length() * 2), &bytes_written, nullptr)) {
			const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_writef), _file_name.c_str() };
			_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_ERRORTYPE | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
			CloseHandle(file);
			return;
		}
		CloseHandle(file);
	}

	//Open query editor
	if (_PSI.Editor(tmp_file_name.c_str(), L"SQLite query", 0, 0, -1, -1, EF_DISABLESAVEPOS | EF_DISABLEHISTORY, 1, 1, CP_UNICODE) == EEC_MODIFIED) {
		//Read query
		LARGE_INTEGER file_size;
		HANDLE file = CreateFile(tmp_file_name.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
		if (file == INVALID_HANDLE_VALUE || !GetFileSizeEx(file, &file_size)) {
			const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_readf), tmp_file_name.c_str() };
			_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_ERRORTYPE | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
			return;
		}
		DWORD bytes_read = static_cast<DWORD>(file_size.QuadPart);
		if (bytes_read > 1024 * 1024)	//I think SQL query is not so big...
			return;
		vector<unsigned char> file_buff(bytes_read);
		if (!ReadFile(file, &file_buff.front(), bytes_read, &bytes_read, nullptr)) {
			const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_readf), _file_name.c_str() };
			_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_ERRORTYPE | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
			CloseHandle(file);
			return;
		}
		CloseHandle(file);
		DeleteFile(tmp_file_name.c_str());

		//Remove BOM 
		if (file_buff.size() > 2 && file_buff[0] == 0xef && file_buff[1] == 0xbb && file_buff[2] == 0xbf)	//UTF-8
			file_buff.erase(file_buff.begin(), file_buff.begin() + 3);
		else if (file_buff.size() > 1 && file_buff[0] == 0xfe && file_buff[1] == 0xff)	//UTF-16 (BE)
			file_buff.erase(file_buff.begin(), file_buff.begin() + 2);
		else if (file_buff.size() > 1 && file_buff[0] == 0xff && file_buff[1] == 0xfe)	//UTF-16 (LE)
			file_buff.erase(file_buff.begin(), file_buff.begin() + 2);
		else if (file_buff.size() > 3 && file_buff[0] == 0x00 && file_buff[1] == 0x00 && file_buff[1] == 0xfe && file_buff[2] == 0xff)	//UTF-32 (BE)
			file_buff.erase(file_buff.begin(), file_buff.begin() + 4);
		else if (file_buff.size() > 3 && file_buff[0] == 0x00 && file_buff[1] == 0x00 && file_buff[1] == 0xff && file_buff[2] == 0xfe)	//UTF-32 (LE)
			file_buff.erase(file_buff.begin(), file_buff.begin() + 4);
		else if (file_buff.size() > 3 && file_buff[0] == 0x2b && file_buff[1] == 0x2f)	//UTF-7
			file_buff.erase(file_buff.begin(), file_buff.begin() + 4);
		if (file_buff.empty())
			return;
		//Add terminated null
		file_buff.push_back(0);
		file_buff.push_back(0);

		_last_sql_query = reinterpret_cast<const wchar_t*>(&file_buff.front());

		//Replace '\r\n' to '\n'
		size_t r_pos = 0;
		while ((r_pos = _last_sql_query.find('\r', r_pos)) != string::npos)
			_last_sql_query.erase(r_pos, 1);

		open_query(_last_sql_query.c_str());
	}
}


void panel::prepare_panel_info()
{
	_panel_info.col_types.clear();
	_panel_info.col_widths.clear();
	_panel_info.col_titles.clear();
	_panel_info.key_bar.clear();
	_panel_info.status_types = nullptr;
	_panel_info.status_widths = nullptr;

	_panel_info.title = _PSI.GetMsg(&_FPG, ps_title_short);
	_panel_info.title += L": ";
	_panel_info.title += _FSF.PointToName(_file_name.c_str());

	if (_curr_object.empty()) {
		_panel_info.col_types = _panel_info.status_types = L"N,C0,C1";
		_panel_info.col_widths = _panel_info.status_widths = L"0,8,9";
		_panel_info.col_titles.push_back(_PSI.GetMsg(&_FPG, ps_pt_name));
		_panel_info.col_titles.push_back(_PSI.GetMsg(&_FPG, ps_pt_type));
		_panel_info.col_titles.push_back(_PSI.GetMsg(&_FPG, ps_pt_count));
		add_keybar_label(L"DDL", VK_F4);
		add_keybar_label(L"Pragma", VK_F4, SHIFT_PRESSED);
		add_keybar_label(L"Export", VK_F5);
	}
	else {
		assert(!_column_descr.empty());

		_panel_info.title += L" [";
		_panel_info.title += _curr_object;
		_panel_info.title += L']';

		const size_t col_num = _column_descr.size();
		for (size_t i = 0; i < col_num; ++i) {
			if (!_panel_info.col_types.empty())
				_panel_info.col_types += L',';
			_panel_info.col_types += L'C';
			wchar_t col_id[32];
			_itow_s(static_cast<int>(i), col_id, 10);
			_panel_info.col_types += col_id;
			if (!_panel_info.col_widths.empty())
				_panel_info.col_widths += L',';
			_panel_info.col_widths += L'0';
			_panel_info.col_titles.push_back(_column_descr[i].name.c_str());
		}
		add_keybar_label(L"Update", VK_F4);
		add_keybar_label(L"Insert", VK_F4, SHIFT_PRESSED);
		add_keybar_label(L"", VK_F3);
		add_keybar_label(L"", VK_F3, SHIFT_PRESSED);
		add_keybar_label(L"", VK_F5);
	}
	add_keybar_label(L"SQL", VK_F6);
	add_keybar_label(L"", VK_F1, SHIFT_PRESSED);
	add_keybar_label(L"", VK_F2, SHIFT_PRESSED);
	add_keybar_label(L"", VK_F3, SHIFT_PRESSED);
	add_keybar_label(L"", VK_F5, SHIFT_PRESSED);
	add_keybar_label(L"", VK_F6, SHIFT_PRESSED);
	add_keybar_label(L"", VK_F7);
	add_keybar_label(L"", VK_F3, LEFT_ALT_PRESSED | RIGHT_ALT_PRESSED);
	add_keybar_label(L"", VK_F4, LEFT_ALT_PRESSED | RIGHT_ALT_PRESSED);
	add_keybar_label(L"", VK_F5, LEFT_ALT_PRESSED | RIGHT_ALT_PRESSED);
	add_keybar_label(L"", VK_F6, LEFT_ALT_PRESSED | RIGHT_ALT_PRESSED);
	add_keybar_label(L"", VK_F7, LEFT_ALT_PRESSED | RIGHT_ALT_PRESSED);
	for (WORD i = VK_F1; i <= VK_F12; ++i)
		add_keybar_label(L"", i, LEFT_CTRL_PRESSED | RIGHT_CTRL_PRESSED);

	//Configure one panel view for all modes
	_panel_info.modes.clear();
	PanelMode pm;
	ZeroMemory(&pm, sizeof(pm));
	pm.ColumnTypes =  _panel_info.col_types.c_str();
	pm.ColumnWidths = _panel_info.col_widths.c_str();
	pm.ColumnTitles = &_panel_info.col_titles.front();
	pm.StatusColumnTypes = _panel_info.status_types;
	pm.StatusColumnWidths = _panel_info.status_widths;
	_panel_info.modes.resize(10, pm);
}


void panel::add_keybar_label(const wchar_t* label, const WORD vkc, const DWORD cks /*= 0*/)
{
	KeyBarLabel kbl;
	ZeroMemory(&kbl, sizeof(kbl));
	kbl.Text = kbl.LongText = label;
	kbl.Key.VirtualKeyCode = vkc;
	kbl.Key.ControlKeyState = cks;
	_panel_info.key_bar.push_back(kbl);
}


wchar_t* panel::alloc_copy(const wchar_t* src) const
{
	assert(src);
	const size_t data_sz = wcslen(src) + 1;
	wchar_t* data = new wchar_t[data_sz];
	wcscpy_s(data, data_sz, src);
	return data;
}
