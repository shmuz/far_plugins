/**************************************************************************
 *  SQLiteDB plug-in for FAR 3.0                                          *
 *  Copyright (C) 2010-2014 by Artem Senichev <artemsen@gmail.com>        *
 *  https://sourceforge.net/projects/farplugs/                            *
 *                                                                        *
 *  This program is free software: you can redistribute it and/or modify  *
 *  it under the terms of the GNU General Public License as published by  *
 *  the Free Software Foundation, either version 3 of the License, or     *
 *  (at your option) any later version.                                   *
 *                                                                        *
 *  This program is distributed in the hope that it will be useful,       *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *  GNU General Public License for more details.                          *
 *                                                                        *
 *  You should have received a copy of the GNU General Public License     *
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. *
 **************************************************************************/

#pragma once


//! Plug-in strings
enum plugin_string {
	ps_title,
	ps_title_short,
	ps_title_ddl,
	ps_title_pragma,

	ps_cfg_add_pm,
	ps_cfg_prefix,

	ps_pt_name,
	ps_pt_type,
	ps_pt_count,

	ps_reading,
	ps_execsql,

	ps_insert_row_title,
	ps_edit_row_title,
	ps_drop_question,

	ps_exp_title,
	ps_exp_main,
	ps_exp_fmt,
	ps_exp_fmt_text,
	ps_exp_exp,

	ps_err_open,
	ps_err_read,
	ps_err_sql,
	ps_err_readf,
	ps_err_writef,

	ps_save,
	ps_cancel
};
