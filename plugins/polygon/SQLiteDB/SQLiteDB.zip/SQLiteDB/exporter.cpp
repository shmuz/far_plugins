/**************************************************************************
 *  SQLiteDB plug-in for FAR 3.0                                          *
 *  Copyright (C) 2010-2014 by Artem Senichev <artemsen@gmail.com>        *
 *  https://sourceforge.net/projects/farplugs/                            *
 *                                                                        *
 *  This program is free software: you can redistribute it and/or modify  *
 *  it under the terms of the GNU General Public License as published by  *
 *  the Free Software Foundation, either version 3 of the License, or     *
 *  (at your option) any later version.                                   *
 *                                                                        *
 *  This program is distributed in the hope that it will be useful,       *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *  GNU General Public License for more details.                          *
 *                                                                        *
 *  You should have received a copy of the GNU General Public License     *
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. *
 **************************************************************************/

#include "exporter.h"
#include "settings.h"
#include "progress.h"
#include "string_rc.h"

#define MAX_BLOB_LENGTH 100
#define MAX_TEXT_LENGTH 1024


exporter::exporter(const sqlite* db)
: _db(db)
{
	assert(_db);
}


bool exporter::export_data() const
{
	//Get source table/view name
	const intptr_t ppi_len = _PSI.PanelControl(PANEL_ACTIVE, FCTL_GETCURRENTPANELITEM, 0, nullptr);
	if (ppi_len == 0)
		return false;
	vector<unsigned char> ppi_buffer(ppi_len);
	PluginPanelItem* ppi = reinterpret_cast<PluginPanelItem*>(&ppi_buffer.front());
	FarGetPluginPanelItem fgppi;
	ZeroMemory(&fgppi, sizeof(fgppi));
	fgppi.StructSize = sizeof(fgppi);
	fgppi.Size = ppi_buffer.size();
	fgppi.Item = ppi;
	if (!_PSI.PanelControl(PANEL_ACTIVE, FCTL_GETCURRENTPANELITEM, 0, &fgppi))
		return false;
	if (!ppi || wcscmp(ppi->FileName, L"..") == 0 || (ppi->FileAttributes & FILE_ATTRIBUTE_DIRECTORY) == 0)
		return false;
	const wchar_t* db_object_name = ppi->FileName;

	//Get destination path
	wstring dst_file_name;
	const intptr_t fpd_len = _PSI.PanelControl(PANEL_PASSIVE, FCTL_GETPANELDIRECTORY, 0, nullptr);
	if (fpd_len != 0) {
		vector<unsigned char> fpd_buffer(fpd_len);
		FarPanelDirectory* fpd = reinterpret_cast<FarPanelDirectory*>(&fpd_buffer.front());
		fpd->StructSize = sizeof(FarPanelDirectory);
		if (_PSI.PanelControl(PANEL_PASSIVE, FCTL_GETPANELDIRECTORY, static_cast<intptr_t>(fpd_buffer.size()), fpd))
			dst_file_name = fpd->Name;
	}
	if (!dst_file_name.empty() && *dst_file_name.rbegin() != L'\\')
		dst_file_name += L'\\';
	dst_file_name += db_object_name;
	dst_file_name += L".txt";

	FarDialogItem dlg_items[10];
	ZeroMemory(dlg_items, sizeof(dlg_items));

	dlg_items[0].Type = DI_DOUBLEBOX;
	dlg_items[0].X1 = 3;
	dlg_items[0].X2 = 56;
	dlg_items[0].Y1 = 1;
	dlg_items[0].Y2 = 8;
	dlg_items[0].Data = _PSI.GetMsg(&_FPG, ps_exp_title);

	dlg_items[1].Type = DI_TEXT;
	dlg_items[1].X1 = 5;
	dlg_items[1].X2 = 54;
	dlg_items[1].Y1 = 2;
	wstring src_label(16 + wcslen(db_object_name), 0);
	swprintf_s(&src_label.front(), src_label.size(), _PSI.GetMsg(&_FPG, ps_exp_main), db_object_name);
	dlg_items[1].Data = src_label.c_str();

	dlg_items[2].Type = DI_EDIT;
	dlg_items[2].X1 = 5;
	dlg_items[2].X2 = 54;
	dlg_items[2].Y1 = 3;
	dlg_items[2].Data = dst_file_name.c_str();

	dlg_items[3].Type = DI_TEXT;
	dlg_items[3].Y1 = 4;
	dlg_items[3].Flags = DIF_SEPARATOR;

	dlg_items[4].Type = DI_TEXT;
	dlg_items[4].X1 = 5;
	dlg_items[4].X2 = 20;
	dlg_items[4].Y1 = 5;
	dlg_items[4].Data = _PSI.GetMsg(&_FPG, ps_exp_fmt);

	dlg_items[5].Type = DI_RADIOBUTTON;
	dlg_items[5].X1 = 21;
	dlg_items[5].X2 = 29;
	dlg_items[5].Y1 = 5;
	dlg_items[5].Data = L"CSV";
	dlg_items[5].Selected = 1;

	dlg_items[6].Type = DI_RADIOBUTTON;
	dlg_items[6].X1 = 30;
	dlg_items[6].X2 = 44;
	dlg_items[6].Y1 = 5;
	dlg_items[6].Data = _PSI.GetMsg(&_FPG, ps_exp_fmt_text);

	dlg_items[7].Type = DI_TEXT;
	dlg_items[7].Y1 = 6;
	dlg_items[7].Flags = DIF_SEPARATOR;

	dlg_items[8].Type = DI_BUTTON;
	dlg_items[8].Data = _PSI.GetMsg(&_FPG, ps_exp_exp);
	dlg_items[8].Y1 = 7;
	dlg_items[8].Flags = DIF_CENTERGROUP | DIF_DEFAULTBUTTON | DIF_FOCUS;

	dlg_items[9].Type = DI_BUTTON;
	dlg_items[9].Data = _PSI.GetMsg(&_FPG, ps_cancel);
	dlg_items[9].Y1 = 7;
	dlg_items[9].Flags = DIF_CENTERGROUP;

	const HANDLE dlg = _PSI.DialogInit(&_FPG, &_FPG, -1, -1, 60, 10, nullptr, dlg_items, sizeof(dlg_items) / sizeof(dlg_items[0]), 0, FDLG_NONE, nullptr, nullptr);
	const intptr_t rc = _PSI.DialogRun(dlg);
	if (rc < 0 || rc == 9 /* cancel */) {
		_PSI.DialogFree(dlg);
		return false;
	}
	dst_file_name = reinterpret_cast<const wchar_t*>(_PSI.SendDlgMessage(dlg, DM_GETCONSTTEXTPTR, 2, nullptr));
	const format fmt = _PSI.SendDlgMessage(dlg, DM_GETCHECK, 5, nullptr) == BSTATE_CHECKED ? fmt_csv : fmt_text;
	_PSI.DialogFree(dlg);
	return export_data(db_object_name, fmt, dst_file_name.c_str());
}


bool exporter::export_data(const wchar_t* db_object, const format fmt, wstring& file_name) const
{
	assert(db_object && db_object[0]);
	file_name = get_temp_file_name(fmt == fmt_csv ? L"csv" : L"txt");
	return export_data(db_object, fmt, file_name.c_str());
}


bool exporter::export_data(const wchar_t* db_object, const format fmt, const wchar_t* file_name) const
{
	assert(db_object && db_object[0]);
	assert(file_name && file_name[0]);

	//Get row count and  columns description
	unsigned __int64 row_count = 0;
	sqlite::sq_columns columns_descr;
	if (!_db->get_row_count(db_object, row_count) || !_db->read_column_description(db_object, columns_descr)) {
		const wstring err_descr = _db->last_error();
		const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_read), err_descr.c_str() };
		_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
		return false;
	}

	const size_t colimns_count = columns_descr.size();

	progress prg_wnd(ps_reading, row_count);

	//Get maximum with for each column
	vector<size_t> columns_width(colimns_count);
	if (fmt == fmt_text) {
		wstring query = L"select ";
		for (size_t i = 0; i < columns_width.size(); ++i) {
			if (i)
				query += L", ";
			query += L"max(length([";
			query += columns_descr[i].name;
			query += L"]))";
		}
		query += L" from '";
		query += db_object;
		query += L'\'';
		sqlite_statement stmt(_db->db());
		if (stmt.prepare(query.c_str()) == SQLITE_OK && stmt.step_execute() == SQLITE_ROW) {
			for (size_t i = 0; i < columns_width.size(); ++i)
				columns_width[i] = stmt.get_int(static_cast<int>(i));
		}
		else {
			for (size_t i = 0; i < columns_width.size(); ++i)
				columns_width[i] = 20;
		}
		for (size_t i = 0; i < columns_width.size(); ++i) {
			if (columns_width[i] < columns_descr[i].name.length())
				columns_width[i] = columns_descr[i].name.length();
			if (columns_width[i] > MAX_TEXT_LENGTH)
				columns_width[i] = MAX_TEXT_LENGTH;
		}
	}

	//Create output file
	HANDLE file = CreateFile(file_name, GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
	if (file == INVALID_HANDLE_VALUE) {
		prg_wnd.hide();
		const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_writef), file_name };
		_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_ERRORTYPE | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
		return false;
	}
	DWORD bytes_written;

	//Write BOM for text file
	if (fmt == fmt_text) {
		const unsigned char utf16_bom[] = { 0xff, 0xfe };
		WriteFile(file, utf16_bom, sizeof(utf16_bom), &bytes_written, nullptr);
	}

	//Write header (columns names)
	wstring out_text;
	for (size_t i = 0; i < colimns_count; ++i) {
		if (fmt == fmt_csv) {
			out_text += columns_descr[i].name;
			if (i != colimns_count - 1)
				out_text += L';';
		}
		else {
			wstring col_name;
			if (i)
				col_name = L' ';
			col_name += columns_descr[i].name;
			col_name.resize(columns_width[i] + (i && i != colimns_count - 1 ? 2 : 1), L' ');
			out_text += col_name;
			if (i != colimns_count - 1)
				out_text += 0x2502;
		}
	}
	out_text += L"\r\n";

	//Header separator
	if (fmt == fmt_text) {
		for (size_t i = 0; i < columns_descr.size(); ++i) {
			wstring col_sep(columns_width[i] + (i && i != colimns_count - 1 ? 2 : 1), 0x2500);
			out_text += col_sep;
			if (i != colimns_count - 1)
				out_text += 0x253C;
		}
		out_text += L"\r\n";
	}
	WriteFile(file, out_text.c_str(), static_cast<DWORD>(out_text.length() * sizeof(wchar_t)), &bytes_written, nullptr);

	//Read data
	wstring query = L"select * from '";
	query += db_object;
	query += L'\'';
	sqlite_statement stmt(_db->db());
	if (stmt.prepare(query.c_str()) != SQLITE_OK) {
		prg_wnd.hide();
		const wstring err_descr = _db->last_error();
		const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_read), err_descr.c_str() };
		_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
		CloseHandle(file);
		return false;
	}

	int count = 0;
	int state = SQLITE_OK;
	while ((state = stmt.step_execute()) == SQLITE_ROW) {
		if (++count % 100 == 0)
			prg_wnd.update(count);
		if (progress::aborted()) {
			CloseHandle(file);
			return false;
		}

		out_text.clear();
		for (int i = 0; i < static_cast<int>(colimns_count); ++i) {
			wstring col_data;
			get_text(stmt, i, col_data);
			if (fmt == fmt_csv) {
				const bool use_quote = columns_descr[i].type == sqlite::ct_text && col_data.find(L';') != string::npos;
				if (use_quote) {
					out_text += L'"';
					//Replace quote by double quote
					size_t qpos = 0;
					while ((qpos = col_data.find(L'"', qpos)) != string::npos) {
						col_data.insert(qpos, 1, L'"');
						qpos += 2;
					}
				}
				out_text += col_data;
				if (use_quote)
					out_text += L'"';
				if (i != static_cast<int>(colimns_count) - 1)
					out_text += L';';
			}
			else {
				if (i)
					col_data = L" " + col_data;
				col_data.resize(columns_width[i] + (i && i != static_cast<int>(colimns_count) - 1 ? 2 : 1), L' ');
				if (col_data.size() > MAX_TEXT_LENGTH) {
					col_data.erase(MAX_TEXT_LENGTH - 3);
					col_data += L"...";
				}
				out_text += col_data;
				if (i != static_cast<int>(colimns_count) - 1)
					out_text += 0x2502;
			}
		}
		out_text += L"\r\n";

		if (!WriteFile(file, out_text.c_str(), static_cast<DWORD>(out_text.length() * sizeof(wchar_t)), &bytes_written, nullptr)) {
			const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_writef), file_name };
			_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_ERRORTYPE | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
			CloseHandle(file);
			return false;
		}
	}

	CloseHandle(file);

	if (state != SQLITE_DONE) {
		prg_wnd.hide();
		const wstring err_descr = _db->last_error();
		const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_read), err_descr.c_str() };
		_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
		return false;
	}

	return true;
}


wstring exporter::get_temp_file_name(const wchar_t* ext)
{
	wstring tmp_file_name = L"sqlite.tmp";

	wchar_t tmp_path[MAX_PATH];
	if (GetTempPath(MAX_PATH, tmp_path)) {
		wchar_t tmp_name[MAX_PATH];
		if (GetTempFileName(tmp_path, L"sql", 0, tmp_name))
			tmp_file_name = tmp_name;
	}
	if (ext && ext[0]) {
		tmp_file_name += L'.';
		tmp_file_name += ext;
	}
	return tmp_file_name;
}


void exporter::get_text(const sqlite_statement& stmt, const int idx, wstring& data)
{
	if (stmt.column_type(idx) == SQLITE_BLOB) {
		const int blob_len = stmt.get_length(idx);
		wchar_t blob_len_txt[32];
		_itow_s(blob_len, blob_len_txt, 10);
		data = L"[";
		data += blob_len_txt;
		data += L"]:0x";
		const unsigned char* blob_data = static_cast<const unsigned char*>(stmt.get_blob(idx));
		for (int j = 0; j < blob_len && j < MAX_BLOB_LENGTH; ++j) {
			wchar_t h[3];
			swprintf_s(h, L"%02x", blob_data[j]);
			data += h;
		}
		if (blob_len >= MAX_BLOB_LENGTH)
			data += L"...";
	}
	else {
		const wchar_t* txt = stmt.get_text(idx);
		data = txt ? txt : wstring();
		//Replace unreadable symbols
		const size_t len = data.length();
		for (size_t i = 0; i < len; ++i) {
			wchar_t& sym = data[i];
			if (sym < L' ')
				sym = L' ';
		}
	}
}
