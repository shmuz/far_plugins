/**************************************************************************
 *  SQLiteDB plug-in for FAR 3.0                                          *
 *  Copyright (C) 2010-2014 by Artem Senichev <artemsen@gmail.com>        *
 *  https://sourceforge.net/projects/farplugs/                            *
 *                                                                        *
 *  This program is free software: you can redistribute it and/or modify  *
 *  it under the terms of the GNU General Public License as published by  *
 *  the Free Software Foundation, either version 3 of the License, or     *
 *  (at your option) any later version.                                   *
 *                                                                        *
 *  This program is distributed in the hope that it will be useful,       *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *  GNU General Public License for more details.                          *
 *                                                                        *
 *  You should have received a copy of the GNU General Public License     *
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. *
 **************************************************************************/

#include "sqlite.h"

//! SQLite db file header ("SQLite format 3")
static const unsigned char sqlite_db_hdr[] =
	{ 0x53, 0x51, 0x4c, 0x69, 0x74, 0x65, 0x20, 0x66, 0x6f, 0x72, 0x6d, 0x61, 0x74, 0x20, 0x33, 0x00 };

//Custom tokenizer support
static sqlite3_tokenizer		_tokinizer = { nullptr };
static sqlite3_tokenizer_module	_tokinizer_mod;
int fts3_create(int, const char *const*, sqlite3_tokenizer** tokenizer) { *tokenizer = &_tokinizer; return 0; }
int fts3_destroy(sqlite3_tokenizer*) { return 0; }
int fts3_open(sqlite3_tokenizer*, const char*, int, sqlite3_tokenizer_cursor**) { return 0; }
int fts3_close(sqlite3_tokenizer_cursor*) { return 0; }
int fts3_next(sqlite3_tokenizer_cursor*, const char**, int*, int*, int*, int*) { return 0; }

//Collation support
int db_collation(void*, int, const void*, int, const void*) { return 0; }
void db_collation_reg(void*, sqlite3* db, int text_rep, const char* name) { sqlite3_create_collation(db, name, text_rep, nullptr, &db_collation); }
void db_collation_reg16(void*, sqlite3* db, int text_rep, const void* name) { sqlite3_create_collation16(db, name, text_rep, nullptr, &db_collation); }

#define SQLITE_MASTER L"sqlite_master"


sqlite::sqlite()
: _db(nullptr)
{
}


sqlite::~sqlite()
{
	close();
}


bool sqlite::format_supported(const unsigned char* file_hdr, const size_t file_hdr_len)
{
	return (file_hdr &&
		sizeof(sqlite_db_hdr) <= file_hdr_len &&
		memcmp(file_hdr, sqlite_db_hdr, sizeof(sqlite_db_hdr)) == 0);
}


bool sqlite::open(const wchar_t* file_name)
{
	assert(_db == nullptr);
	assert(file_name && *file_name);

	return (sqlite3_open16(file_name, &_db) == SQLITE_OK && prepare_tokenizers() && prepare_collations());
}


void sqlite::close()
{
	if (_db != nullptr) {
		sqlite3_close(_db);
		_db = nullptr;
	}
}


wstring sqlite::last_error() const
{
	wstring rc;

	if (!_db)
		rc = L"Error: Database not initialized";
	else {
		wchar_t err_code[32];
		_itow_s(sqlite3_errcode(_db), err_code, 10);
		rc = L"Error: [";
		rc += err_code;
		rc += L"]";
		const wchar_t* sqlite_err = static_cast<const wchar_t*>(sqlite3_errmsg16(_db));
		if (sqlite_err) {
			rc += L' ';
			rc += sqlite_err;
		}
	}
	return rc;
}


bool sqlite::get_objects_list(sq_objects& objects) const
{
	assert(_db);

	//Add master table
	sq_object master_table;
	master_table.name = SQLITE_MASTER;
	master_table.row_count = 0;
	master_table.type = ot_master;
	objects.push_back(master_table);

	//Add tables/views
	sqlite_statement stmt(_db);
	if (stmt.prepare(L"select name,type from " SQLITE_MASTER) != SQLITE_OK)
		return false;
	while (stmt.step_execute() == SQLITE_ROW) {
		sq_object obj;
		obj.name = stmt.get_text(0);
		obj.row_count = 0;
		obj.type = object_type_by_name(stmt.get_text(1));
		objects.push_back(obj);
	}

	//Get tables row count
	for (vector<sq_object>::iterator it = objects.begin(); it != objects.end(); ++it) {
		if (it->type == ot_master || it->type == ot_table || it->type == ot_view) {
			wstring query = L"select count(*) from '";
			query += it->name;
			query += L'\'';
			if (stmt.prepare(query.c_str()) == SQLITE_OK && stmt.step_execute() == SQLITE_ROW)
				it->row_count = stmt.get_int64(0);
		}
	}
	return true;
}


bool sqlite::execute_query(const wchar_t* query) const
{
	sqlite_statement stmt(_db);
	if (stmt.prepare(query) != SQLITE_OK)
		return false;
	const int state = stmt.step_execute();
	return state == SQLITE_DONE || state == SQLITE_OK || state == SQLITE_ROW;
}


bool sqlite::read_column_description(const wchar_t* object_name, sq_columns& columns) const
{
	assert(_db);
	assert(object_name && object_name[0]);

	wstring query = L"pragma table_info('";
	query += object_name;
	query += L"')";
	sqlite_statement stmt(_db);
	if (stmt.prepare(query.c_str()) != SQLITE_OK)
		return false;
	while (stmt.step_execute() == SQLITE_ROW) {
		sq_column col;
		col.name = stmt.get_text(1);
		col.type = ct_text;
		const wchar_t* ct = stmt.get_text(2);
		if (wcsncmp(ct, L"INT", 3) == 0 ||
			wcsncmp(ct, L"TINYINT", 7) == 0 ||
			wcsncmp(ct, L"SMALLINT", 8) == 0 ||
			wcsncmp(ct, L"MEDIUMINT", 9) == 0 ||
			wcsncmp(ct, L"BIGINT", 6) == 0 ||
			wcsncmp(ct, L"NUMERIC", 7) == 0 ||
			wcsncmp(ct, L"DECIMAL", 7) == 0 ||
			wcsncmp(ct, L"BOOLEAN", 7) == 0) {
				col.type = ct_integer;
		}
		else if (wcscmp(ct, L"BLOB") == 0)
			col.type = ct_blob;
		else if (wcsncmp(ct, L"REAL", 4) == 0 ||
			wcsncmp(ct, L"DOUBLE", 6) == 0 ||
			wcsncmp(ct, L"FLOAT", 5) == 0) {
				col.type = ct_float;
		}

		columns.push_back(col);
	}

	return true;
}


bool sqlite::get_row_count(const wchar_t* object_name, unsigned __int64& count) const
{
	assert(_db);
	assert(object_name && object_name[0]);

	wstring query = L"select count(*) from '";
	query += object_name;
	query += L'\'';
	sqlite_statement stmt(_db);
	if (stmt.prepare(query.c_str()) != SQLITE_OK || stmt.step_execute() != SQLITE_ROW)
		return false;
	count = stmt.get_int64(0);
	return true;
}


bool sqlite::get_creation_sql(const wchar_t* object_name, wstring& query) const
{
	assert(_db);
	assert(object_name && object_name[0]);

	if (_wcsicmp(object_name, SQLITE_MASTER) == 0)
		return false;
	sqlite_statement stmt(_db);
	if (stmt.prepare(L"select sql from " SQLITE_MASTER L" where name=?") != SQLITE_OK)
		return false;
	if (stmt.bind(1, object_name) != SQLITE_OK)
		return false;
	if (stmt.step_execute() != SQLITE_ROW)
		return false;
	const wchar_t* txt = stmt.get_text(0);
	if (!txt)
		return false;
	query = txt;
	return true;
}


sqlite::obj_type sqlite::get_object_type(const wchar_t* object_name) const
{
	assert(_db);
	assert(object_name && object_name[0]);

	if (_wcsicmp(object_name, SQLITE_MASTER) == 0)
		return ot_master;
	sqlite_statement stmt(_db);
	if (stmt.prepare(L"select type from " SQLITE_MASTER L" where name=?") != SQLITE_OK)
		return ot_unknown;
	if (stmt.bind(1, object_name) != SQLITE_OK)
		return ot_unknown;
	if (stmt.step_execute() != SQLITE_ROW)
		return ot_unknown;
	return object_type_by_name(stmt.get_text(0));
}


sqlite::obj_type sqlite::object_type_by_name(const wchar_t* type_name) const
{
	assert(type_name && type_name[0]);
	if (!type_name || type_name[0] == 0)
		return ot_unknown;
	if (_wcsicmp(type_name, L"table") == 0)
		return ot_table;
	if (_wcsicmp(type_name, L"view") == 0)
		return ot_view;
	if (_wcsicmp(type_name, L"index") == 0)
		return ot_index;
	return ot_unknown;
}


bool sqlite::prepare_tokenizers() const
{
	//Initialize dummy tokenizer
	if (!_tokinizer.pModule) {
		_tokinizer_mod.iVersion = 0;
		_tokinizer_mod.xCreate = &fts3_create;
		_tokinizer_mod.xDestroy = &fts3_destroy;
		_tokinizer_mod.xOpen = &fts3_open;
		_tokinizer_mod.xClose = &fts3_close;
		_tokinizer_mod.xNext = &fts3_next;
		_tokinizer.pModule = &_tokinizer_mod;
	}

	//Read tokenizers names and register it as dummy stub
	sqlite_statement stmt(_db);
	if (stmt.prepare(L"select sql from " SQLITE_MASTER L" where type='table'") != SQLITE_OK)
		return false;
	while (stmt.step_execute() == SQLITE_ROW) {
		const wchar_t* cs = stmt.get_text(0);
		if (!cs)
			continue;
		wstring crt_sql = cs;
		transform(crt_sql.begin(), crt_sql.end(), crt_sql.begin(), ::tolower);
		if (crt_sql.find(L"fts3") == string::npos)
			continue;
		const wchar_t* tok = L"tokenize ";
		const size_t tok_pos = crt_sql.find(tok);
		if (tok_pos == string::npos)
			continue;
		const size_t tok_name_b = tok_pos + wcslen(tok);
		const size_t tok_name_e = crt_sql.find_first_of(L", )", tok_name_b);
		if (tok_name_e == string::npos)
			continue;
		const wstring tokenizer_name = wstring(cs).substr(tok_name_b, tok_name_e - tok_name_b);
		//Register tokenizer
		static const sqlite3_tokenizer_module* ptr = &_tokinizer_mod;
		sqlite_statement stmt_rt(_db);
		if (stmt_rt.prepare(L"select fts3_tokenizer(?, ?)") != SQLITE_OK ||
			stmt_rt.bind(1, tokenizer_name.c_str()) != SQLITE_OK ||
			stmt_rt.bind(2, &ptr, sizeof(ptr)) != SQLITE_OK ||
			stmt_rt.step_execute() != SQLITE_OK)
			return false;
	}

	return true;
}


bool sqlite::prepare_collations() const
{
	return
		sqlite3_collation_needed16(_db, nullptr, &db_collation_reg16) == SQLITE_OK &&
		sqlite3_collation_needed(_db, nullptr, &db_collation_reg) == SQLITE_OK;

}
