/**************************************************************************
 *  SQLiteDB plug-in for FAR 3.0                                          *
 *  Copyright (C) 2010-2014 by Artem Senichev <artemsen@gmail.com>        *
 *  https://sourceforge.net/projects/farplugs/                            *
 *                                                                        *
 *  This program is free software: you can redistribute it and/or modify  *
 *  it under the terms of the GNU General Public License as published by  *
 *  the Free Software Foundation, either version 3 of the License, or     *
 *  (at your option) any later version.                                   *
 *                                                                        *
 *  This program is distributed in the hope that it will be useful,       *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *  GNU General Public License for more details.                          *
 *                                                                        *
 *  You should have received a copy of the GNU General Public License     *
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. *
 **************************************************************************/

#pragma once

#include "sqlite.h"


class editor
{
public:
	/**
	 * Constructor.
	 * \param db DB instance
	 * \param table_name edited table name
	 */
	editor(const sqlite* db, const wchar_t* table_name);

	/**
	 * Create table row (insert).
	 */
	void insert() const;

	/**
	 * Edit table row (update).
	 */
	void update() const;

	/**
	 * Remove (drop) tables/views/rows etc.
	 * \param items far panel items list
	 * \param items_count number of items
	 * \return operation result state (false on error)
	 */
	bool remove(PluginPanelItem* items, const size_t items_count) const;

private:
	//! Edit field description
	struct field {
		sqlite::sq_column column;
		wstring value;
	};

	/**
	 * Edit (GUI).
	 * \param db_data DB data map (column-type-value)
	 * \param create_mode mode (true for create new row)
	 * \return false if user canceled operation
	 */
	bool edit(vector<field>& db_data, const bool create_mode) const;

	struct row_control {
		FarDialogItem label;
		FarDialogItem semi;
		FarDialogItem field;
	};
	
	/**
	 * Create row control.
	 * \param name label
	 * \param value current value
	 * \param poz_y vertical position
	 * \param width_name name width
	 * \param width_val value width
	 * \param ro read-only flag
	 * \return created control
	 */
	row_control create_row_control(const wchar_t* name, const wchar_t* value, const size_t poz_y, const size_t width_name, const size_t width_val, const bool ro) const;

	/**
	 * Execute update/insert query.
	 * \param row_id row id (for update), nullptr for insert
	 * \param db_data data description
	 * \return operation result state (false on error)
	 */
	bool exec_update(const wchar_t* row_id, const vector<field>& db_data) const;

private:
	const sqlite*	_db;			///< DB instance
	wstring			_table_name;	///< Edited table name
};
