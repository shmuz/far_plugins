/**************************************************************************
 *  SQLiteDB plug-in for FAR 3.0                                          *
 *  Copyright (C) 2010-2014 by Artem Senichev <artemsen@gmail.com>        *
 *  https://sourceforge.net/projects/farplugs/                            *
 *                                                                        *
 *  This program is free software: you can redistribute it and/or modify  *
 *  it under the terms of the GNU General Public License as published by  *
 *  the Free Software Foundation, either version 3 of the License, or     *
 *  (at your option) any later version.                                   *
 *                                                                        *
 *  This program is distributed in the hope that it will be useful,       *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *  GNU General Public License for more details.                          *
 *                                                                        *
 *  You should have received a copy of the GNU General Public License     *
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. *
 **************************************************************************/

#include "editor.h"
#include "exporter.h"
#include "string_rc.h"


editor::editor(const sqlite* db, const wchar_t* table_name)
: _db(db), _table_name(table_name ? table_name : wstring())
{
	assert(_db);
}


void editor::update() const
{
	assert(!_table_name.empty());

	//Get edited row id
	const intptr_t ppi_len = _PSI.PanelControl(PANEL_ACTIVE, FCTL_GETCURRENTPANELITEM, 0, nullptr);
	if (ppi_len == 0)
		return;
	vector<unsigned char> buffer(ppi_len);
	PluginPanelItem* ppi = reinterpret_cast<PluginPanelItem*>(&buffer.front());
	FarGetPluginPanelItem fgppi;
	ZeroMemory(&fgppi, sizeof(fgppi));
	fgppi.StructSize = sizeof(fgppi);
	fgppi.Size = buffer.size();
	fgppi.Item = ppi;
	if (!_PSI.PanelControl(PANEL_ACTIVE, FCTL_GETCURRENTPANELITEM, 0, &fgppi))
		return;
	if (!ppi || wcscmp(ppi->FileName, L"..") == 0)
		return;

	const unsigned __int64 row_id = ppi->AllocationSize;

	//Read current row data
	vector<field> db_data;
	wstring query = L"select * from ";
	query += _table_name;
	query += L" where rowid=";
	wchar_t id_txt[32];
	_i64tow_s(static_cast<__int64>(row_id), id_txt, sizeof(id_txt) / sizeof(wchar_t), 10);
	query += id_txt;
	sqlite_statement stmt(_db->db());
	if (stmt.prepare(query.c_str()) != SQLITE_OK || stmt.step_execute() != SQLITE_ROW) {
		const wstring err_descr = _db->last_error();
		const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_read), err_descr.c_str() };
		_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
		return;
	}
	const int col_num = stmt.column_count();
	for (int i = 0; i < col_num; ++i) {
		field f;
		f.column.name = stmt.column_name(i);
		switch (stmt.column_type(i)) {
			case SQLITE_INTEGER: f.column.type = sqlite::ct_integer; break;
			case SQLITE_FLOAT: f.column.type = sqlite::ct_float; break;
			case SQLITE3_TEXT: f.column.type = sqlite::ct_text; break;
			case SQLITE_BLOB:
			default:
				f.column.type = sqlite::ct_blob; break;
		}
		exporter::get_text(stmt, i, f.value);

		db_data.push_back(f);
	}
	stmt.close();

	if (edit(db_data, false) && exec_update(id_txt, db_data)) {
		_PSI.PanelControl(PANEL_ACTIVE, FCTL_UPDATEPANEL, 0, nullptr);
		PanelRedrawInfo pri;
		ZeroMemory(&pri, sizeof(pri));
		pri.StructSize = sizeof(pri);
		_PSI.PanelControl(PANEL_ACTIVE, FCTL_REDRAWPANEL, 0, &pri);
	}
}


void editor::insert() const
{
	assert(!_table_name.empty());

	vector<field> db_data;

	//Get columns description
	sqlite::sq_columns columns_descr;
	if (!_db->read_column_description(_table_name.c_str(), columns_descr)) {
		const wstring err_descr = _db->last_error();
		const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_read), err_descr.c_str() };
		_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
		return;
	}
	db_data.reserve(columns_descr.size());
	for (sqlite::sq_columns::const_iterator it = columns_descr.begin(); it != columns_descr.end(); ++it) {
		field f;
		f.column = *it;
		if (f.column.type == sqlite::ct_blob)
			f.column.type = sqlite::ct_text;	//Allow edit
		db_data.push_back(f);
	}

	if (edit(db_data, true) && exec_update(nullptr, db_data)) {
		_PSI.PanelControl(PANEL_ACTIVE, FCTL_UPDATEPANEL, 0, nullptr);
		PanelRedrawInfo pri;
		ZeroMemory(&pri, sizeof(pri));
		pri.StructSize = sizeof(pri);
		_PSI.PanelControl(PANEL_ACTIVE, FCTL_REDRAWPANEL, 0, &pri);
	}
}


bool editor::edit(vector<field>& db_data, const bool create_mode) const
{
	//Calculate dialog's size
	size_t max_wnd_width = 80;
	SMALL_RECT rc_far_wnd;
	if (_PSI.AdvControl(&_FPG, ACTL_GETFARRECT, 0, &rc_far_wnd))
		max_wnd_width = rc_far_wnd.Right + 1;
	size_t max_label_length = 0;
	size_t max_value_length = 0;
	for (vector<field>::const_iterator it = db_data.begin(); it != db_data.end(); ++it) {
		const size_t label_len = it->column.name.length();
		const size_t value_len = it->value.length();
		if (max_label_length < label_len)
			max_label_length = label_len;
		if (max_value_length < value_len)
			max_value_length = value_len;
	}
	if (max_value_length < 40)
		max_value_length = 40;
	if (max_value_length + max_label_length + 12 > max_wnd_width)
		max_value_length = max_wnd_width - max_label_length - 12;
	const size_t dlg_height = 6 + /* border, buttons etc */ db_data.size();
	size_t dlg_width = 12 + /* border, buttons etc */ max_label_length + max_value_length;
	if (dlg_width < 30)
		dlg_width = 30;

	//Build dialog
	vector<FarDialogItem> dlg_items;

	FarDialogItem dlg_item;

	ZeroMemory(&dlg_item, sizeof(dlg_item));
	dlg_item.Type = DI_DOUBLEBOX;
	dlg_item.X1 = 3;
	dlg_item.X2 = dlg_width - 4;
	dlg_item.Y1 = 1;
	dlg_item.Y2 = dlg_height - 2;
	dlg_item.Data = _PSI.GetMsg(&_FPG, create_mode ? ps_insert_row_title : ps_edit_row_title);
	dlg_items.push_back(dlg_item);

	map<wstring, intptr_t> editor_fields;
	size_t y_pos = 2;
	for (vector<field>::const_iterator it = db_data.begin(); it != db_data.end(); ++it) {
		const wchar_t* val = it->value.c_str();
		row_control row_ctl = create_row_control(it->column.name.c_str(), val, y_pos++, max_label_length, max_value_length, it->column.type == sqlite::ct_blob);
		if (it == db_data.begin())
			row_ctl.field.Flags |= DIF_FOCUS;
		dlg_items.push_back(row_ctl.label);
		dlg_items.push_back(row_ctl.semi);
		dlg_items.push_back(row_ctl.field);
		editor_fields.insert(make_pair(it->column.name, dlg_items.size() - 1));
	}

	ZeroMemory(&dlg_item, sizeof(dlg_item));
	dlg_item.Type = DI_TEXT;
	dlg_item.Y1 = dlg_height - 4;
	dlg_item.Flags = DIF_SEPARATOR;
	dlg_items.push_back(dlg_item);
	dlg_item.Type = DI_BUTTON;
	dlg_item.Y1 = dlg_height - 3;
	dlg_item.Data = _PSI.GetMsg(&_FPG, ps_save);
	dlg_item.Flags = DIF_CENTERGROUP | DIF_DEFAULTBUTTON;
	dlg_items.push_back(dlg_item);
	dlg_item.Type = DI_BUTTON;
	dlg_item.Y1 = dlg_height - 3;
	dlg_item.Data = _PSI.GetMsg(&_FPG, ps_cancel);
	dlg_item.Flags = DIF_CENTERGROUP;
	dlg_items.push_back(dlg_item);

	const HANDLE dlg = _PSI.DialogInit(&_FPG, &_FPG, -1, -1, dlg_width, dlg_height, nullptr, &dlg_items.front(), dlg_items.size(), 0, FDLG_NONE, nullptr, nullptr);
	const intptr_t rc = _PSI.DialogRun(dlg);
	if (rc < 0 || rc == static_cast<intptr_t>(dlg_items.size()) - 1 /* cancel */) {
		_PSI.DialogFree(dlg);
		return false;
	}

	//Get changed data
	db_data.clear();
	for (map<wstring, intptr_t>::const_iterator it = editor_fields.begin(); it != editor_fields.end(); ++it) {
		if (_PSI.SendDlgMessage(dlg, DM_EDITUNCHANGEDFLAG, it->second, reinterpret_cast<void*>(-1)) == 0) {
			field f;
			f.column.name = it->first;
			f.value = reinterpret_cast<const wchar_t*>(_PSI.SendDlgMessage(dlg, DM_GETCONSTTEXTPTR, it->second, nullptr));
			db_data.push_back(f);
		}
	}

	_PSI.DialogFree(dlg);
	return !db_data.empty();
}


bool editor::remove(PluginPanelItem* items, const size_t items_count) const
{
	if (items_count == 1 && items->FileName && wcscmp(items->FileName, L"..") == 0)
		return false;

	const wchar_t* quest_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_drop_question) };
	if (_PSI.Message(&_FPG, &_FPG, FMSG_MB_YESNO | FMSG_WARNING, nullptr, quest_msg, sizeof(quest_msg) / sizeof(quest_msg[0]), 0) != 0)
		return false;

	if (_table_name.empty()) {
		for (size_t i = 0; i < items_count; ++i) {
			wstring query = L"drop ";
			if (items[i].AllocationSize == sqlite::ot_table)
				query += L"table";
			else if (items[i].AllocationSize == sqlite::ot_view)
				query += L"view";
			else if (items[i].AllocationSize == sqlite::ot_index)
				query += L"index";
			else
				continue;
			query += L' ';
			query += items[i].FileName;

			if (!_db->execute_query(query.c_str())) {
				const wstring err_descr = _db->last_error();
				const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_sql), query.c_str(), err_descr.c_str() };
				_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
				break;
			}
		}
	}
	else {
		wstring query = L"delete from ";
		query += _table_name;
		query += L" where rowid in (";
		for (size_t i = 0; i < items_count; ++i) {
			if (i)
				query += L',';
			wchar_t id_txt[32];
			_i64tow_s(static_cast<__int64>(items[i].AllocationSize), id_txt, sizeof(id_txt) / sizeof(wchar_t), 10);
			query += id_txt;
		}
		query += L')';

		if (!_db->execute_query(query.c_str())) {
			const wstring err_descr = _db->last_error();
			const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_sql), query.c_str(), err_descr.c_str() };
			_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
		}
	}

	return true;
}


bool editor::exec_update(const wchar_t* row_id, const vector<field>& db_data) const
{
	wstring query;

	if (row_id && row_id[0]) {
		//Update query
		query = L"update '";
		query += _table_name;
		query += L"' set ";
		for (vector<field>::const_iterator it = db_data.begin(); it != db_data.end(); ++it) {
			if (it != db_data.begin())
				query += L',';
			query += it->column.name;
			query += L"=?";
		}
		query += L" where rowid=";
		query += row_id;
	}
	else {
		//Insert query
		query = L"insert into '";
		query += _table_name;
		query += L"' (";
		for (vector<field>::const_iterator it = db_data.begin(); it != db_data.end(); ++it) {
			if (it != db_data.begin())
				query += L',';
			query += it->column.name;
		}
		query += L") values (";
		for (size_t i = 0; i < db_data.size(); ++i) {
			if (i != 0)
				query += L',';
			query += L'?';
		}
		query += L')';
	}

	sqlite_statement stmt(_db->db());
	if (stmt.prepare(query.c_str()) != SQLITE_OK) {
		const wstring err_descr = _db->last_error();
		const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_sql), err_descr.c_str() };
		_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
		return false;
	}
	int idx = 0;
	for (vector<field>::const_iterator it = db_data.begin(); it != db_data.end(); ++it) {
		++idx;
		int bind_rc = SQLITE_OK;
		if (it->column.type == sqlite::ct_float)
			bind_rc = stmt.bind(idx, _wtof(it->value.c_str()));
		else if (it->column.type == sqlite::ct_integer)
			bind_rc = stmt.bind(idx, _wtoi64(it->value.c_str()));
		else
			bind_rc = stmt.bind(idx, it->value.c_str());
		if (bind_rc != SQLITE_OK) {
			const wstring err_descr = _db->last_error();
			const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_sql), err_descr.c_str() };
			_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
			return false;
		}
	}
	if (stmt.step_execute() != SQLITE_DONE) {
		const wstring err_descr = _db->last_error();
		const wchar_t* err_msg[] = { _PSI.GetMsg(&_FPG, ps_title_short), _PSI.GetMsg(&_FPG, ps_err_sql), err_descr.c_str() };
		_PSI.Message(&_FPG, &_FPG, FMSG_WARNING | FMSG_MB_OK, nullptr, err_msg, sizeof(err_msg) / sizeof(err_msg[0]), 0);
		return false;
	}
	return true;
}


editor::row_control editor::create_row_control(const wchar_t* name, const wchar_t* value, const size_t poz_y, const size_t width_name, const size_t width_val, const bool ro) const
{
	row_control rc;
	ZeroMemory(&rc, sizeof(rc));

	rc.label.Type = DI_TEXT;
	rc.label.X1 = 5;
	rc.label.X2 = 5 + width_name - 1;
	rc.label.Y1 = poz_y;
	rc.label.Data = name;

	rc.semi.Type = DI_TEXT;
	rc.semi.X1 = rc.semi.X2 = rc.label.X2 + 1;
	rc.semi.Y1 = poz_y;
	rc.semi.Data = L":";

	rc.field.Type = DI_EDIT;
	rc.field.X1 = rc.semi.X1 + 2;
	rc.field.X2 = rc.field.X1 + width_val - 1;
	rc.field.Y1 = poz_y;
	rc.field.Data = value;
	if (ro)
		rc.field.Flags = DIF_READONLY;

	return rc;
}
