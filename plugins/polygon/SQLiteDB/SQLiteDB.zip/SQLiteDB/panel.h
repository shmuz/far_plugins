/**************************************************************************
 *  SQLiteDB plug-in for FAR 3.0                                          *
 *  Copyright (C) 2010-2014 by Artem Senichev <artemsen@gmail.com>        *
 *  https://sourceforge.net/projects/farplugs/                            *
 *                                                                        *
 *  This program is free software: you can redistribute it and/or modify  *
 *  it under the terms of the GNU General Public License as published by  *
 *  the Free Software Foundation, either version 3 of the License, or     *
 *  (at your option) any later version.                                   *
 *                                                                        *
 *  This program is distributed in the hope that it will be useful,       *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *  GNU General Public License for more details.                          *
 *                                                                        *
 *  You should have received a copy of the GNU General Public License     *
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. *
 **************************************************************************/

#pragma once

#include "common.h"
#include "sqlite.h"


class panel
{
private:
	panel() {}

public:
	/**
	 * Open database file.
	 * \param file_name database file name
	 * \param silent silent mode flag (true to show error message)
	 * \return panel instance (nullptr on error)
	 */
	static panel* open(const wchar_t* file_name, const bool silent);

	/**
	 * Open metadata.
	 * \return operation result state (false on error)
	 */
	bool open_database();

	/**
	 * Open row data from object (table or view).
	 * \param object_name object name
	 * \return operation result state (false on error)
	 */
	bool open_object(const wchar_t* object_name);

	/**
	 * Open query result.
	 * \param query SQL query
	 * \return operation result state (false on error)
	 */
	bool open_query(const wchar_t* query);

	/**
	 * Get panel info.
	 * \param info panel info
	 */
	void get_panel_info(OpenPanelInfo* info);

	/**
	 * Get panel list.
	 * \param items far panel items list
	 * \param items_count number of items
	 * \return operation result state (false on error)
	 */
	bool get_panel_list(PluginPanelItem** items, size_t& items_count);

	/**
	 * Free panel file list.
	 * \param items far panel items list
	 * \param items_count number of items
	 */
	void free_panel_list(PluginPanelItem* items, const size_t items_count);

	/**
	 * Delete items.
	 * \param items far panel items list
	 * \param items_count number of items
	 * \return false if no items was deleted
	 */
	bool delete_items(PluginPanelItem* items, const size_t items_count);

	/**
	 * Handle keyboard event.
	 * \param key_event keyboard event
	 * \return true if event handled
	 */
	bool handle_keyboard(const KEY_EVENT_RECORD& key_event);

private:
	/**
	 * Get database metadata (list of the db's objects).
	 * \param items far panel items list
	 * \param items_count number of items
	 * \return operation result state (false on error)
	 */
	bool get_panel_list_db(PluginPanelItem** items, size_t& items_count);

	/**
	 * Get table or view content.
	 * \param items far panel items list
	 * \param items_count number of items
	 * \return operation result state (false on error)
	 */
	bool get_panel_list_obj(PluginPanelItem** items, size_t& items_count);

	/**
	 * Get data from custom query.
	 * \param items far panel items list
	 * \param items_count number of items
	 * \return operation result state (false on error)
	 */
	bool get_panel_list_query(PluginPanelItem** items, size_t& items_count);

	/**
	 * View DB object data.
	 */
	void view_db_object();

	/**
	 * View DB object create statement.
	 */
	void view_db_create_sql();

	/**
	 * View DB pragma statements.
	 */
	void view_pragma_statements();

	/**
	 * Edit and execute user's SQL query.
	 */
	void edit_sql_query();

	/**
	 * Prepare panel info description.
	 */
	void prepare_panel_info();

	/**
	 * Add keybar label description to internal variable.
	 * \param label keybar label
	 * \param vkc virtual key code
	 * \param cks control key state
	 */
	void add_keybar_label(const wchar_t* label, const WORD vkc, const DWORD cks = 0);

	/**
	 * Allocate memory and copy string to it.
	 * \param src source string
	 * \return pointer to allocated memory
	 */
	wchar_t* alloc_copy(const wchar_t* src) const;

private:
	//! Panel modes.
	enum panel_mode {
		pm_db,
		pm_table,
		pm_view,
		pm_query
	};

	sqlite				_db;				///< Database instance
	panel_mode			_panel_mode;		///< Current panel mode
	sqlite::sq_columns	_column_descr;		///< Column description
	wstring				_curr_object;		///< Current viewing object name (directory name for Far)
	wstring				_file_name;			///< SQLite db file name
	wstring				_last_sql_query;	///< Last used user's SQL query

	struct {
		wstring					title;		///< Panel title
 		wstring					col_types;
 		wstring					col_widths;
		vector<const wchar_t*>	col_titles;
 		const wchar_t*			status_types;
 		const wchar_t*			status_widths;
		vector<PanelMode>		modes;
		vector<KeyBarLabel>		key_bar;
	}		_panel_info;		///< Panel info description
};
