/**************************************************************************
 *  SQLiteDB plug-in for FAR 3.0                                          *
 *  Copyright (C) 2010-2014 by Artem Senichev <artemsen@gmail.com>        *
 *  https://sourceforge.net/projects/farplugs/                            *
 *                                                                        *
 *  This program is free software: you can redistribute it and/or modify  *
 *  it under the terms of the GNU General Public License as published by  *
 *  the Free Software Foundation, either version 3 of the License, or     *
 *  (at your option) any later version.                                   *
 *                                                                        *
 *  This program is distributed in the hope that it will be useful,       *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *  GNU General Public License for more details.                          *
 *                                                                        *
 *  You should have received a copy of the GNU General Public License     *
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. *
 **************************************************************************/

#pragma once

#include "common.h"
#pragma warning(push, 1)
#include "sqlite/sqlite3.h"
#include "sqlite/fts3_tokenizer.h"
#pragma warning(pop)


class sqlite
{
public:
	//! Database object types.
	enum obj_type {
		ot_unknown,	///< Unknown type
		ot_master,	///< Master table (sqlite_master)
		ot_table,	///< Table
		ot_view,	///< View
		ot_index	///< Index
	};

	//! Database object description.
	struct sq_object {
		wstring name;				///< Object name
		obj_type type;				///< Object type
		unsigned __int64 row_count;	///< Number of records (count), only for tables and views
	};
	typedef vector<sq_object> sq_objects;

	//! Column types.
	enum col_type {
		ct_integer,
		ct_float,
		ct_blob,
		ct_text
	};

	//! Column description.
	struct sq_column {
		wstring name;				///< Name
		col_type type;				///< Type
	};
	typedef vector<sq_column> sq_columns;

	sqlite();
	~sqlite();

	/**
	 * Check for sqlite format of file.
	 * \param file_hdr file header data pointer
	 * \param file_hdr_len file header data length
	 * \return true if it is sqlite db format
	 */
	static bool format_supported(const unsigned char* file_hdr, const size_t file_hdr_len);

	/**
	 * Open DB.
	 * \param file_name DB file name
	 * \return operation result status (false on error)
	 */
	bool open(const wchar_t* file_name);

	/**
	 * Close DB.
	 */
	void close();

	/**
	 * Get last error description.
	 * \return last error description
	 */
	wstring last_error() const;

	/**
	 * Get DB objects list.
	 * \param objects output objects list
	 * \return operation result status (false on error)
	 */
	bool get_objects_list(sq_objects& objects) const;

	/**
	 * Execute query.
	 * \param query SQL query
	 * \return operation result status (false on error)
	 */
	bool execute_query(const wchar_t* query) const;

	/**
	 * Read column description of the DB object (table or view).
	 * \param object_name db object name (table or view)
	 * \param columns column description
	 * \return operation result status (false on error)
	 */
	bool read_column_description(const wchar_t* object_name, sq_columns& columns) const;

	/**
	 * Ret row count for table or view.
	 * \param object_name table or view name
	 * \param count rows count
	 * \return operation result status (false on error)
	 */
	bool get_row_count(const wchar_t* object_name, unsigned __int64& count) const;

	/**
	 * Get creation SQL query for specified object.
	 * \param object_name db object name
	 * \param query SQL query used to create object
	 * \return operation result status (false on error)
	 */
	bool get_creation_sql(const wchar_t* object_name, wstring& query) const;

	/**
	 * Get object type.
	 * \param object_name object name
	 * \return object type
	 */
	obj_type get_object_type(const wchar_t* object_name) const;

	/**
	 * Get SQLite DB handle.
	 * \return SQLite DB handle
	 */
	sqlite3* db() const { return _db; }

private:
	/**
	 * Get object type by name.
	 * \param type_name type name
	 * \return type identifier
	 */
	obj_type object_type_by_name(const wchar_t* type_name) const;

	/**
	 * Register tokenizers used by DB.
	 * \return operation result status (false on error)
	 */
	bool prepare_tokenizers() const;

	/**
	 * Register collations used by DB.
	 * \return operation result status (false on error)
	 */
	bool prepare_collations() const;

private:
	sqlite3* _db;	///< DB instance
};


/**
 * SQLite statement wrapper.
 */
class sqlite_statement
{
public:
	sqlite_statement(sqlite3* db) : _stmt(NULL), _db(db)				{ assert(_db); }
	~sqlite_statement()													{ close(); }

	//Prepare query
	inline int prepare(const wchar_t* query)							{ close(); return sqlite3_prepare16_v2(_db, query, -1, &_stmt, NULL); }

	//Bind query parameter
	inline int bind(const int index, const void* val, const int size)	{ return sqlite3_bind_blob(_stmt, index, val, size, SQLITE_TRANSIENT); }
	inline int bind(const int index, const double val)					{ return sqlite3_bind_double(_stmt, index, val); }
	inline int bind(const int index, const int val)						{ return sqlite3_bind_int(_stmt, index, val); }
	inline int bind(const int index, const sqlite3_int64 val)			{ return sqlite3_bind_int64(_stmt, index, val); }
	inline int bind(const int index, const char* val)					{ return sqlite3_bind_text(_stmt, index, val, static_cast<int>(strlen(val)), SQLITE_TRANSIENT); }
	inline int bind(const int index, const wchar_t* val)				{ return sqlite3_bind_text16(_stmt, index, val, static_cast<int>(wcslen(val)) * sizeof(wchar_t), SQLITE_TRANSIENT); }
	inline int bind_null(const int index)								{ return sqlite3_bind_null(_stmt, index); }

	//Execute query step
	inline int step_execute()											{ return sqlite3_step(_stmt); }

	//Query result - get column properties
	inline int column_count() const										{ return sqlite3_column_count(_stmt); };
	inline int column_type(const int index)	const						{ return sqlite3_column_type(_stmt, index); };
	inline const wchar_t* column_name(const int index) const			{ return static_cast<const wchar_t*>(sqlite3_column_name16(_stmt, index)); };

	//Query result - get row data
	inline int get_length(const int index) const						{ return sqlite3_column_bytes(_stmt, index); }
	inline const void* get_blob(const int index) const					{ return sqlite3_column_blob(_stmt, index); }
	inline int get_int(const int index) const							{ return sqlite3_column_int(_stmt, index); }
	inline sqlite3_int64 get_int64(const int index) const				{ return sqlite3_column_int64(_stmt, index); }
	inline const wchar_t* get_text(const int index) const				{ return static_cast<const wchar_t*>(sqlite3_column_text16(_stmt, index)); }

	//Close statement
	inline void close()													{ if (_stmt) { sqlite3_finalize(_stmt); _stmt = NULL; }	}

private:
	sqlite3_stmt*	_stmt;	///< SQLite statement
	sqlite3*		_db;	///< SQLite database
};
